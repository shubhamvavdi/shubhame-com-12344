import { 
  users, categories, products, cartItems, orders, orderItems,
  type User, type InsertUser,
  type Category, type InsertCategory,
  type Product, type InsertProduct,
  type CartItem, type InsertCartItem,
  type Order, type InsertOrder,
  type OrderItem, type InsertOrderItem,
  type ProductWithCategory,
  type CartItemWithProduct,
  type OrderWithItems
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateStripeCustomerId(userId: number, customerId: string): Promise<User>;
  updateUserStripeInfo(userId: number, info: { customerId: string; subscriptionId: string }): Promise<User>;

  // Categories
  getCategories(): Promise<Category[]>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;

  // Products
  getProducts(filters?: { category?: string; featured?: boolean; search?: string }): Promise<ProductWithCategory[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;

  // Cart
  getCartItems(sessionId: string): Promise<CartItemWithProduct[]>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: number, quantity: number): Promise<CartItem | undefined>;
  removeFromCart(id: number): Promise<boolean>;
  clearCart(sessionId: string): Promise<boolean>;

  // Orders
  getOrders(): Promise<Order[]>;
  getOrder(id: number): Promise<OrderWithItems | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  addOrderItem(item: InsertOrderItem): Promise<OrderItem>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;

  // Admin Analytics
  getDashboardStats(): Promise<{
    totalOrders: number;
    totalRevenue: number;
    totalCustomers: number;
    totalProducts: number;
    recentOrders: Order[];
    topProducts: ProductWithCategory[];
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private products: Map<number, Product>;
  private cartItems: Map<number, CartItem>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  private currentUserId: number;
  private currentCategoryId: number;
  private currentProductId: number;
  private currentCartItemId: number;
  private currentOrderId: number;
  private currentOrderItemId: number;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.products = new Map();
    this.cartItems = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    this.currentUserId = 1;
    this.currentCategoryId = 1;
    this.currentProductId = 1;
    this.currentCartItemId = 1;
    this.currentOrderId = 1;
    this.currentOrderItemId = 1;
    
    this.initializeData();
  }

  private initializeData() {
    // Initialize admin user
    const adminUser: User = {
      id: this.currentUserId++,
      username: "admin",
      email: "admin@shophub.com",
      password: "admin123", // In real app, this should be hashed
      role: "admin",
      stripeCustomerId: null,
      stripeSubscriptionId: null,
      createdAt: new Date()
    };
    this.users.set(adminUser.id, adminUser);

    // Initialize categories
    const categoriesData = [
      {
        name: "Electronics",
        slug: "electronics",
        icon: "fas fa-laptop",
        description: "Latest tech gadgets and electronics",
        productCount: 120
      },
      {
        name: "Fashion",
        slug: "fashion",
        icon: "fas fa-tshirt",
        description: "Trendy clothing and accessories",
        productCount: 200
      },
      {
        name: "Home & Garden",
        slug: "home",
        icon: "fas fa-home",
        description: "Everything for your home and garden",
        productCount: 150
      },
      {
        name: "Sports",
        slug: "sports",
        icon: "fas fa-dumbbell",
        description: "Sports equipment and fitness gear",
        productCount: 80
      }
    ];

    categoriesData.forEach(category => {
      const id = this.currentCategoryId++;
      this.categories.set(id, { 
        ...category, 
        id,
        description: category.description || null,
        productCount: category.productCount || null
      });
    });

    // Initialize products
    const productsData: InsertProduct[] = [
      {
        name: "Premium Wireless Headphones",
        description: "High-quality sound with noise cancellation technology for immersive audio experience",
        price: "199.00",
        originalPrice: "249.00",
        image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        category: "electronics",
        rating: "4.8",
        reviewCount: 128,
        inStock: true,
        featured: true,
        badge: "Sale"
      },
      {
        name: "Stylish Summer Dress",
        description: "Comfortable and elegant dress perfect for any summer occasion",
        price: "89.00",
        image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        category: "fashion",
        rating: "4.6",
        reviewCount: 94,
        inStock: true,
        featured: true
      },
      {
        name: "Latest Smartphone Pro",
        description: "Advanced camera system with AI features and lightning-fast performance",
        price: "899.00",
        image: "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        category: "electronics",
        rating: "4.9",
        reviewCount: 256,
        inStock: true,
        featured: true,
        badge: "New"
      },
      {
        name: "Ergonomic Office Chair",
        description: "Comfortable design perfect for long work hours with lumbar support",
        price: "299.00",
        image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        category: "home",
        rating: "4.7",
        reviewCount: 187,
        inStock: true,
        featured: true,
        badge: "Bestseller"
      },
      {
        name: "Wireless Gaming Mouse",
        description: "Precision gaming mouse with customizable RGB lighting",
        price: "79.00",
        image: "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        category: "electronics",
        rating: "4.5",
        reviewCount: 89,
        inStock: true,
        featured: false
      },
      {
        name: "Designer Handbag",
        description: "Luxury leather handbag with premium craftsmanship",
        price: "159.00",
        image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        category: "fashion",
        rating: "4.8",
        reviewCount: 156,
        inStock: true,
        featured: false
      },
      {
        name: "Smart Fitness Watch",
        description: "Track your health and fitness with this advanced smartwatch",
        price: "249.00",
        image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        category: "sports",
        rating: "4.6",
        reviewCount: 203,
        inStock: true,
        featured: false
      },
      {
        name: "Modern Coffee Table",
        description: "Sleek and modern coffee table perfect for any living room",
        price: "199.00",
        image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        category: "home",
        rating: "4.4",
        reviewCount: 67,
        inStock: true,
        featured: false
      }
    ];

    productsData.forEach(product => {
      const id = this.currentProductId++;
      this.products.set(id, { 
        ...product, 
        id, 
        createdAt: new Date(),
        originalPrice: product.originalPrice || null,
        rating: product.rating || null,
        reviewCount: product.reviewCount || null,
        inStock: product.inStock !== false,
        featured: product.featured || false,
        badge: product.badge || null
      });
    });
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      role: insertUser.role || "customer",
      stripeCustomerId: insertUser.stripeCustomerId || null,
      stripeSubscriptionId: insertUser.stripeSubscriptionId || null,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateStripeCustomerId(userId: number, customerId: string): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error('User not found');
    
    const updatedUser = { ...user, stripeCustomerId: customerId };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async updateUserStripeInfo(userId: number, info: { customerId: string; subscriptionId: string }): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error('User not found');
    
    const updatedUser = { 
      ...user, 
      stripeCustomerId: info.customerId,
      stripeSubscriptionId: info.subscriptionId
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  // Categories
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(category => category.slug === slug);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.currentCategoryId++;
    const category: Category = { 
      ...insertCategory, 
      id,
      description: insertCategory.description || null,
      productCount: insertCategory.productCount || null
    };
    this.categories.set(id, category);
    return category;
  }

  async updateCategory(id: number, updateData: Partial<InsertCategory>): Promise<Category | undefined> {
    const category = this.categories.get(id);
    if (!category) return undefined;
    
    const updatedCategory = { 
      ...category, 
      ...updateData,
      description: updateData.description || category.description,
      productCount: updateData.productCount || category.productCount
    };
    this.categories.set(id, updatedCategory);
    return updatedCategory;
  }

  async deleteCategory(id: number): Promise<boolean> {
    return this.categories.delete(id);
  }

  // Products
  async getProducts(filters?: { category?: string; featured?: boolean; search?: string }): Promise<ProductWithCategory[]> {
    let products = Array.from(this.products.values());

    if (filters?.category) {
      products = products.filter(product => product.category === filters.category);
    }

    if (filters?.featured !== undefined) {
      products = products.filter(product => product.featured === filters.featured);
    }

    if (filters?.search) {
      const searchTerm = filters.search.toLowerCase();
      products = products.filter(product => 
        product.name.toLowerCase().includes(searchTerm) ||
        product.description.toLowerCase().includes(searchTerm)
      );
    }

    return products.map(product => {
      const category = Array.from(this.categories.values()).find(cat => cat.slug === product.category);
      return {
        ...product,
        categoryName: category?.name
      };
    });
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    const product: Product = { 
      ...insertProduct, 
      id, 
      createdAt: new Date(),
      featured: insertProduct.featured ?? null,
      originalPrice: insertProduct.originalPrice ?? null,
      rating: insertProduct.rating ?? null,
      reviewCount: insertProduct.reviewCount ?? null,
      inStock: insertProduct.inStock ?? null,
      badge: insertProduct.badge ?? null
    };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: number, updateData: Partial<InsertProduct>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;
    
    const updatedProduct = { 
      ...product, 
      ...updateData,
      originalPrice: updateData.originalPrice || product.originalPrice,
      rating: updateData.rating || product.rating,
      reviewCount: updateData.reviewCount || product.reviewCount,
      inStock: updateData.inStock !== undefined ? updateData.inStock : product.inStock,
      featured: updateData.featured !== undefined ? updateData.featured : product.featured,
      badge: updateData.badge || product.badge
    };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }

  // Cart
  async getCartItems(sessionId: string): Promise<CartItemWithProduct[]> {
    const items = Array.from(this.cartItems.values()).filter(item => item.sessionId === sessionId);
    
    return items.map(item => {
      const product = this.products.get(item.productId);
      if (!product) {
        throw new Error(`Product with id ${item.productId} not found`);
      }
      return {
        ...item,
        product
      };
    });
  }

  async addToCart(insertCartItem: InsertCartItem): Promise<CartItem> {
    // Check if item already exists in cart
    const existingItem = Array.from(this.cartItems.values()).find(
      item => item.productId === insertCartItem.productId && item.sessionId === insertCartItem.sessionId
    );

    const quantity = insertCartItem.quantity || 1;

    if (existingItem) {
      // Update quantity
      const updatedItem = { ...existingItem, quantity: existingItem.quantity + quantity };
      this.cartItems.set(existingItem.id, updatedItem);
      return updatedItem;
    }

    const id = this.currentCartItemId++;
    const cartItem: CartItem = { ...insertCartItem, id, quantity };
    this.cartItems.set(id, cartItem);
    return cartItem;
  }

  async updateCartItem(id: number, quantity: number): Promise<CartItem | undefined> {
    const item = this.cartItems.get(id);
    if (!item) return undefined;
    
    const updatedItem = { ...item, quantity };
    this.cartItems.set(id, updatedItem);
    return updatedItem;
  }

  async removeFromCart(id: number): Promise<boolean> {
    return this.cartItems.delete(id);
  }

  async clearCart(sessionId: string): Promise<boolean> {
    const itemsToDelete = Array.from(this.cartItems.entries())
      .filter(([_, item]) => item.sessionId === sessionId)
      .map(([id, _]) => id);
    
    itemsToDelete.forEach(id => this.cartItems.delete(id));
    return true;
  }

  // Orders
  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }

  async getOrder(id: number): Promise<OrderWithItems | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;

    const items = Array.from(this.orderItems.values())
      .filter(item => item.orderId === id)
      .map(item => {
        const product = this.products.get(item.productId);
        if (!product) {
          throw new Error(`Product with id ${item.productId} not found`);
        }
        return { ...item, product };
      });

    return { ...order, items };
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.currentOrderId++;
    const order: Order = { 
      ...insertOrder, 
      id, 
      createdAt: new Date(),
      status: insertOrder.status || "pending",
      customerPhone: insertOrder.customerPhone || null
    };
    this.orders.set(id, order);
    return order;
  }

  async addOrderItem(insertOrderItem: InsertOrderItem): Promise<OrderItem> {
    const id = this.currentOrderItemId++;
    const orderItem: OrderItem = { ...insertOrderItem, id };
    this.orderItems.set(id, orderItem);
    return orderItem;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const updatedOrder = { ...order, status };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  async getDashboardStats(): Promise<{
    totalOrders: number;
    totalRevenue: number;
    totalCustomers: number;
    totalProducts: number;
    recentOrders: Order[];
    topProducts: ProductWithCategory[];
  }> {
    const orders = Array.from(this.orders.values());
    const users = Array.from(this.users.values()).filter(u => u.role === "customer");
    const products = Array.from(this.products.values());
    
    const totalRevenue = orders.reduce((sum, order) => sum + parseFloat(order.totalAmount), 0);
    const recentOrders = orders
      .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
      .slice(0, 5);
    
    // Get top products by order frequency
    const productOrderCount = new Map<number, number>();
    const orderItems = Array.from(this.orderItems.values());
    
    orderItems.forEach(item => {
      const current = productOrderCount.get(item.productId) || 0;
      productOrderCount.set(item.productId, current + item.quantity);
    });
    
    const topProducts = products
      .map(product => ({
        ...product,
        categoryName: this.categories.get(
          Array.from(this.categories.values()).find(c => c.slug === product.category)?.id || 0
        )?.name
      }))
      .sort((a, b) => (productOrderCount.get(b.id) || 0) - (productOrderCount.get(a.id) || 0))
      .slice(0, 5);

    return {
      totalOrders: orders.length,
      totalRevenue,
      totalCustomers: users.length,
      totalProducts: products.length,
      recentOrders,
      topProducts
    };
  }
}

export const storage = new MemStorage();
