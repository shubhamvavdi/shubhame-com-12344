import { useState } from "react";
import { Navigation } from "@/components/navigation";
import { HeroSection } from "@/components/hero-section";
import { CategoriesSection } from "@/components/categories-section";
import { ProductsSection } from "@/components/products-section";
import { AboutSection } from "@/components/about-section";
import { ContactSection } from "@/components/contact-section";
import { Footer } from "@/components/footer";
import { ShoppingCart } from "@/components/shopping-cart";

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    setSearchQuery(""); // Clear search when selecting category
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setSelectedCategory("all"); // Reset category when searching
  };

  const handleShopNow = () => {
    setSelectedCategory("all");
    setSearchQuery("");
  };

  return (
    <div className="min-h-screen bg-white">
      <Navigation onSearch={handleSearch} />
      <HeroSection onShopNow={handleShopNow} />
      <CategoriesSection onCategorySelect={handleCategorySelect} />
      <ProductsSection 
        selectedCategory={selectedCategory} 
        searchQuery={searchQuery}
      />
      <AboutSection />
      <ContactSection />
      <Footer />
      <ShoppingCart />
    </div>
  );
}
