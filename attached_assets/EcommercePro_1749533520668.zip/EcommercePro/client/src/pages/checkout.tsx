import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { loadStripe } from "@stripe/stripe-js";
import { Elements, PaymentElement, useStripe, useElements } from "@stripe/react-stripe-js";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, CreditCard, ShoppingBag } from "lucide-react";
import { useCart } from "@/context/cart-context";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatPrice } from "@/lib/products";

// Initialize Stripe
const stripePromise = import.meta.env.VITE_STRIPE_PUBLIC_KEY ? 
  loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY) : null;

function CheckoutForm({ customerInfo, setCustomerInfo }: {
  customerInfo: any;
  setCustomerInfo: (info: any) => void;
}) {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const { cartItems, cartTotal, clearCart } = useCart();
  const [_, setLocation] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      // Create order first
      const orderResponse = await apiRequest("POST", "/api/orders", customerInfo);
      
      if (orderResponse.ok) {
        const { error } = await stripe.confirmPayment({
          elements,
          confirmParams: {
            return_url: `${window.location.origin}/order-success`,
          },
        });

        if (error) {
          toast({
            title: "Payment Failed",
            description: error.message,
            variant: "destructive",
          });
        } else {
          clearCart();
          toast({
            title: "Payment Successful",
            description: "Your order has been placed successfully!",
          });
          setLocation("/");
        }
      } else {
        toast({
          title: "Order Creation Failed",
          description: "Failed to create order. Please try again.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="firstName">First Name</Label>
          <Input
            id="firstName"
            value={customerInfo.firstName}
            onChange={(e) => setCustomerInfo({ ...customerInfo, firstName: e.target.value })}
            required
          />
        </div>
        <div>
          <Label htmlFor="lastName">Last Name</Label>
          <Input
            id="lastName"
            value={customerInfo.lastName}
            onChange={(e) => setCustomerInfo({ ...customerInfo, lastName: e.target.value })}
            required
          />
        </div>
      </div>

      <div>
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          value={customerInfo.email}
          onChange={(e) => setCustomerInfo({ ...customerInfo, email: e.target.value })}
          required
        />
      </div>

      <div>
        <Label htmlFor="phone">Phone Number</Label>
        <Input
          id="phone"
          type="tel"
          value={customerInfo.phone}
          onChange={(e) => setCustomerInfo({ ...customerInfo, phone: e.target.value })}
        />
      </div>

      {stripePromise && (
        <div>
          <Label>Payment Information</Label>
          <div className="mt-2 p-4 border rounded-lg">
            <PaymentElement />
          </div>
        </div>
      )}

      <Button
        type="submit"
        className="w-full"
        disabled={!stripe || isProcessing}
        size="lg"
      >
        <CreditCard className="mr-2 h-5 w-5" />
        {isProcessing ? "Processing..." : `Pay ${formatPrice(cartTotal)}`}
      </Button>
    </form>
  );
}

export default function Checkout() {
  const { cartItems, cartTotal, cartCount } = useCart();
  const [_, setLocation] = useLocation();
  const { toast } = useToast();
  const [clientSecret, setClientSecret] = useState("");
  const [customerInfo, setCustomerInfo] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    customerName: "",
    customerEmail: "",
    customerPhone: "",
  });

  // Redirect if cart is empty
  useEffect(() => {
    if (cartCount === 0) {
      toast({
        title: "Cart is Empty",
        description: "Add some items to your cart before checkout.",
        variant: "destructive",
      });
      setLocation("/");
    }
  }, [cartCount, setLocation, toast]);

  // Update customer info when form fields change
  useEffect(() => {
    setCustomerInfo(prev => ({
      ...prev,
      customerName: `${prev.firstName} ${prev.lastName}`.trim(),
      customerEmail: prev.email,
      customerPhone: prev.phone,
    }));
  }, [customerInfo.firstName, customerInfo.lastName, customerInfo.email, customerInfo.phone]);

  // Create payment intent
  useEffect(() => {
    if (cartTotal > 0 && stripePromise) {
      apiRequest("POST", "/api/create-payment-intent", { amount: cartTotal })
        .then((res) => res.json())
        .then((data) => {
          if (data.clientSecret) {
            setClientSecret(data.clientSecret);
          } else {
            toast({
              title: "Payment Setup Failed",
              description: data.message || "Could not initialize payment.",
              variant: "destructive",
            });
          }
        })
        .catch(() => {
          toast({
            title: "Error",
            description: "Failed to setup payment. Stripe may not be configured.",
            variant: "destructive",
          });
        });
    }
  }, [cartTotal, toast]);

  if (cartCount === 0) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Shop
          </Button>
          <h1 className="text-3xl font-bold text-gray-900">Checkout</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Order Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <ShoppingBag className="mr-2 h-5 w-5" />
                Order Summary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {cartItems.map((item) => (
                <div key={item.id} className="flex items-center space-x-4">
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-16 h-16 object-cover rounded"
                  />
                  <div className="flex-1">
                    <h3 className="font-medium">{item.product.name}</h3>
                    <p className="text-sm text-gray-600">Qty: {item.quantity}</p>
                  </div>
                  <p className="font-medium">
                    {formatPrice(parseFloat(item.product.price) * item.quantity)}
                  </p>
                </div>
              ))}
              
              <Separator />
              
              <div className="flex justify-between items-center text-lg font-bold">
                <span>Total:</span>
                <span>{formatPrice(cartTotal)}</span>
              </div>
            </CardContent>
          </Card>

          {/* Payment Form */}
          <Card>
            <CardHeader>
              <CardTitle>Payment Details</CardTitle>
            </CardHeader>
            <CardContent>
              {stripePromise && clientSecret ? (
                <Elements 
                  stripe={stripePromise} 
                  options={{ 
                    clientSecret,
                    appearance: {
                      theme: 'stripe',
                    },
                  }}
                >
                  <CheckoutForm 
                    customerInfo={customerInfo} 
                    setCustomerInfo={setCustomerInfo} 
                  />
                </Elements>
              ) : (
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        value={customerInfo.firstName}
                        onChange={(e) => setCustomerInfo({ ...customerInfo, firstName: e.target.value })}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        value={customerInfo.lastName}
                        onChange={(e) => setCustomerInfo({ ...customerInfo, lastName: e.target.value })}
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={customerInfo.email}
                      onChange={(e) => setCustomerInfo({ ...customerInfo, email: e.target.value })}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={customerInfo.phone}
                      onChange={(e) => setCustomerInfo({ ...customerInfo, phone: e.target.value })}
                    />
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <p className="text-sm text-yellow-800">
                      Payment processing is currently unavailable. Please contact us to complete your order.
                    </p>
                  </div>

                  <Button
                    className="w-full"
                    size="lg"
                    onClick={async () => {
                      try {
                        const response = await apiRequest("POST", "/api/orders", {
                          customerName: `${customerInfo.firstName} ${customerInfo.lastName}`.trim(),
                          customerEmail: customerInfo.email,
                          customerPhone: customerInfo.phone,
                        });
                        
                        if (response.ok) {
                          toast({
                            title: "Order Placed",
                            description: "Your order has been placed successfully! We'll contact you for payment.",
                          });
                          setLocation("/");
                        } else {
                          throw new Error("Failed to place order");
                        }
                      } catch (error) {
                        toast({
                          title: "Error",
                          description: "Failed to place order. Please try again.",
                          variant: "destructive",
                        });
                      }
                    }}
                    disabled={!customerInfo.firstName || !customerInfo.email}
                  >
                    <ShoppingBag className="mr-2 h-5 w-5" />
                    Place Order
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}