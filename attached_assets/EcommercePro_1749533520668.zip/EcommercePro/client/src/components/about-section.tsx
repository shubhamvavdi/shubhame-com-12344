import { Truck, Shield, Star, Headphones } from "lucide-react";

export function AboutSection() {
  const features = [
    {
      icon: Truck,
      title: "Fast Delivery",
      description: "Same-day & next-day options",
      bgColor: "bg-blue-50",
      iconColor: "text-blue-600"
    },
    {
      icon: Shield,
      title: "Secure Payments",
      description: "Multiple gateways & encryption",
      bgColor: "bg-green-50",
      iconColor: "text-green-600"
    },
    {
      icon: Star,
      title: "5-Star Reviews",
      description: "Customer satisfaction guaranteed",
      bgColor: "bg-yellow-50",
      iconColor: "text-yellow-600"
    },
    {
      icon: Headphones,
      title: "24/7 Support",
      description: "Always here to help",
      bgColor: "bg-purple-50",
      iconColor: "text-purple-600"
    }
  ];

  return (
    <section id="about" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">
              About ShopHub
            </h2>
            <p className="text-lg text-gray-600 mb-6">
              ShopHub is a modern e-commerce platform designed to provide seamless 
              shopping experiences. Built with cutting-edge technologies including 
              React.js, Node.js, and MongoDB, our platform offers lightning-fast 
              performance and intuitive user interfaces.
            </p>
            <p className="text-lg text-gray-600 mb-8">
              From electronics to fashion, from home essentials to gaming gear, we 
              provide a comprehensive marketplace with secure payments, real-time 
              inventory tracking, and exceptional customer service.
            </p>

            <div className="grid grid-cols-2 gap-6">
              {features.map((feature, index) => {
                const IconComponent = feature.icon;
                return (
                  <div
                    key={index}
                    className={`text-center p-4 ${feature.bgColor} rounded-lg`}
                  >
                    <IconComponent className={`h-8 w-8 ${feature.iconColor} mx-auto mb-2`} />
                    <h4 className="font-semibold mb-1">{feature.title}</h4>
                    <p className="text-sm text-gray-600">{feature.description}</p>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
              alt="Modern e-commerce shopping experience"
              className="rounded-2xl shadow-2xl"
            />
            <div className="absolute -bottom-4 -left-4 bg-white p-6 rounded-lg shadow-lg">
              <div className="text-2xl font-bold text-amber-500">99.9%</div>
              <div className="text-sm text-gray-600">Customer Satisfaction</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
