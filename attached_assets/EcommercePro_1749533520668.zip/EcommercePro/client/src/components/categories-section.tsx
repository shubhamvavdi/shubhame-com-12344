import { productCategories } from "@/lib/products";

interface CategoriesSectionProps {
  onCategorySelect?: (category: string) => void;
}

export function CategoriesSection({ onCategorySelect }: CategoriesSectionProps) {
  const handleCategoryClick = (categorySlug: string) => {
    onCategorySelect?.(categorySlug);
    const element = document.getElementById("products");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="categories" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            Shop by Category
          </h2>
          <p className="text-xl text-gray-600">
            Discover our wide range of products across multiple categories
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {productCategories.map((category) => (
            <div
              key={category.id}
              className="group cursor-pointer"
              onClick={() => handleCategoryClick(category.id)}
            >
              <div
                className={`bg-gradient-to-br ${category.gradient} rounded-2xl p-8 text-center hover:shadow-lg transition-all duration-300 group-hover:scale-105`}
              >
                <i
                  className={`${category.icon} text-4xl ${category.iconColor} mb-4`}
                ></i>
                <h3 className="font-semibold text-gray-800 mb-2">
                  {category.name}
                </h3>
                <p className="text-sm text-gray-600">
                  {category.productCount}+ Products
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
