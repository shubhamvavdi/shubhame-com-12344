import { Button } from "@/components/ui/button";
import { ShoppingBag, Play } from "lucide-react";

interface HeroSectionProps {
  onShopNow?: () => void;
}

export function HeroSection({ onShopNow }: HeroSectionProps) {
  const handleShopNow = () => {
    onShopNow?.();
    const element = document.getElementById("products");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const stats = [
    { value: "500+", label: "Products" },
    { value: "1000+", label: "Happy Customers" },
    { value: "99.9%", label: "Uptime" },
  ];

  return (
    <section id="home" className="relative bg-gradient-to-r from-primary to-secondary text-white">
      <div className="absolute inset-0 bg-black opacity-20"></div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Next-Generation{" "}
              <span className="text-amber-400">E-Commerce</span> Experience
            </h1>
            <p className="text-xl mb-8 text-blue-100">
              Discover amazing products with fast delivery, secure payments, and
              exceptional customer service. Your trusted shopping destination.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <Button
                onClick={handleShopNow}
                className="bg-amber-500 hover:bg-amber-600 text-white px-8 py-3 text-lg font-semibold"
                size="lg"
              >
                <ShoppingBag className="mr-2 h-5 w-5" />
                Shop Now
              </Button>
              <Button
                variant="outline"
                className="border-2 border-white text-white hover:bg-white hover:text-primary px-8 py-3 text-lg font-semibold"
                size="lg"
              >
                <Play className="mr-2 h-5 w-5" />
                View Demo
              </Button>
            </div>
            <div className="grid grid-cols-3 gap-8 text-center">
              {stats.map((stat, index) => (
                <div key={index}>
                  <div className="text-3xl font-bold text-amber-400">
                    {stat.value}
                  </div>
                  <div className="text-blue-200">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="hidden lg:block">
            <div className="bg-white rounded-2xl shadow-2xl p-6 transform rotate-3 hover:rotate-0 transition-transform duration-500">
              <div className="bg-slate-100 rounded-lg p-4 mb-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-semibold text-gray-800">Live Orders</h3>
                  <span className="bg-green-500 text-white px-2 py-1 rounded-full text-sm">
                    24
                  </span>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Electronics</span>
                    <span className="text-green-600">+12%</span>
                  </div>
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Fashion</span>
                    <span className="text-green-600">+8%</span>
                  </div>
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Home & Garden</span>
                    <span className="text-green-600">+15%</span>
                  </div>
                </div>
              </div>
              <div className="text-center text-gray-800">
                <div className="text-2xl font-bold text-amber-500">4.9/5</div>
                <div className="text-sm">Customer Rating</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
