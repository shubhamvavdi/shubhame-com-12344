import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Heart, Star, StarHalf, ArrowRight } from "lucide-react";
import { ProductWithCategory } from "@shared/schema";
import { useCart } from "@/context/cart-context";
import { formatPrice, getBadgeColor, renderStars } from "@/lib/products";

interface ProductsSectionProps {
  selectedCategory?: string;
  searchQuery?: string;
}

export function ProductsSection({ selectedCategory, searchQuery }: ProductsSectionProps) {
  const [activeFilter, setActiveFilter] = useState("all");
  const { addToCart } = useCart();

  const { data: products = [], isLoading } = useQuery<ProductWithCategory[]>({
    queryKey: ["/api/products", { 
      category: selectedCategory === "all" ? undefined : selectedCategory,
      featured: activeFilter === "featured" ? true : undefined,
      search: searchQuery
    }],
  });

  const featuredProducts = products.filter(product => product.featured);
  const displayProducts = activeFilter === "featured" ? featuredProducts : products;

  const filters = [
    { id: "all", label: "All" },
    { id: "featured", label: "Featured" },
    { id: "electronics", label: "Electronics" },
    { id: "fashion", label: "Fashion" },
    { id: "home", label: "Home" },
  ];

  const handleAddToCart = (productId: number) => {
    addToCart(productId, 1);
  };

  const renderProductStars = (rating: string | number) => {
    const { fullStars, hasHalfStar, emptyStars } = renderStars(rating);
    const stars = [];

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="w-4 h-4 fill-yellow-400 text-yellow-400" />);
    }

    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="w-4 h-4 fill-yellow-400 text-yellow-400" />);
    }

    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="w-4 h-4 text-gray-300" />);
    }

    return stars;
  };

  if (isLoading) {
    return (
      <section id="products" className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="bg-white rounded-2xl shadow-lg overflow-hidden animate-pulse">
                <div className="h-64 bg-gray-300"></div>
                <div className="p-6">
                  <div className="h-4 bg-gray-300 rounded mb-2"></div>
                  <div className="h-3 bg-gray-300 rounded mb-4"></div>
                  <div className="h-6 bg-gray-300 rounded mb-4"></div>
                  <div className="h-10 bg-gray-300 rounded"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="products" className="py-16 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              {searchQuery ? `Search Results for "${searchQuery}"` : 
               selectedCategory && selectedCategory !== "all" ? 
               `${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} Products` : 
               "Featured Products"}
            </h2>
            <p className="text-xl text-gray-600">
              {searchQuery ? `Found ${displayProducts.length} products` : "Handpicked products with amazing deals"}
            </p>
          </div>
          <div className="hidden md:flex space-x-4">
            {filters.map((filter) => (
              <Button
                key={filter.id}
                variant={activeFilter === filter.id ? "default" : "outline"}
                onClick={() => setActiveFilter(filter.id)}
                className={activeFilter === filter.id ? "bg-primary text-white" : ""}
              >
                {filter.label}
              </Button>
            ))}
          </div>
        </div>

        {displayProducts.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No products found matching your criteria.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {displayProducts.map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 group"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  {product.badge && (
                    <div className="absolute top-4 left-4">
                      <Badge className={`${getBadgeColor(product.badge)} text-white font-semibold`}>
                        {product.badge}
                      </Badge>
                    </div>
                  )}
                  <div className="absolute top-4 right-4">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="bg-white p-2 rounded-full shadow-md hover:bg-gray-50 transition-colors"
                    >
                      <Heart className="h-4 w-4 text-gray-400 hover:text-red-500" />
                    </Button>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="font-semibold text-lg mb-2">{product.name}</h3>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                    {product.description}
                  </p>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <span className="text-2xl font-bold text-primary">
                        {formatPrice(product.price)}
                      </span>
                      {product.originalPrice && (
                        <span className="text-lg text-gray-400 line-through ml-2">
                          {formatPrice(product.originalPrice)}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center">
                      <div className="flex">
                        {renderProductStars(product.rating || 0)}
                      </div>
                      <span className="text-sm text-gray-600 ml-1">
                        ({product.reviewCount})
                      </span>
                    </div>
                  </div>
                  <Button
                    onClick={() => handleAddToCart(product.id)}
                    className="w-full bg-primary hover:bg-secondary text-white font-semibold"
                    disabled={!product.inStock}
                  >
                    {product.inStock ? (
                      <>
                        <i className="fas fa-cart-plus mr-2"></i>
                        Add to Cart
                      </>
                    ) : (
                      "Out of Stock"
                    )}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="text-center mt-12">
          <Button className="bg-primary hover:bg-secondary text-white px-8 py-3 font-semibold">
            View All Products
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  );
}
