export const productCategories = [
  {
    id: "electronics",
    name: "Electronics",
    icon: "fas fa-laptop",
    description: "Latest tech gadgets and electronics",
    productCount: 120,
    gradient: "from-blue-50 to-blue-100",
    iconColor: "text-blue-600"
  },
  {
    id: "fashion",
    name: "Fashion",
    icon: "fas fa-tshirt",
    description: "Trendy clothing and accessories",
    productCount: 200,
    gradient: "from-pink-50 to-pink-100",
    iconColor: "text-pink-600"
  },
  {
    id: "home",
    name: "Home & Garden",
    icon: "fas fa-home",
    description: "Everything for your home and garden",
    productCount: 150,
    gradient: "from-green-50 to-green-100",
    iconColor: "text-green-600"
  },
  {
    id: "sports",
    name: "Sports",
    icon: "fas fa-dumbbell",
    description: "Sports equipment and fitness gear",
    productCount: 80,
    gradient: "from-orange-50 to-orange-100",
    iconColor: "text-orange-600"
  }
];

export const getBadgeColor = (badge?: string | null) => {
  switch (badge?.toLowerCase()) {
    case "sale":
      return "bg-red-500";
    case "new":
      return "bg-green-500";
    case "bestseller":
      return "bg-blue-500";
    default:
      return "bg-gray-500";
  }
};

export const formatPrice = (price: string | number) => {
  const numPrice = typeof price === "string" ? parseFloat(price) : price;
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(numPrice);
};

export const formatRating = (rating: string | number) => {
  const numRating = typeof rating === "string" ? parseFloat(rating) : rating;
  return numRating.toFixed(1);
};

export const renderStars = (rating: string | number) => {
  const numRating = typeof rating === "string" ? parseFloat(rating) : rating;
  const fullStars = Math.floor(numRating);
  const hasHalfStar = numRating % 1 >= 0.5;
  const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

  return {
    fullStars,
    hasHalfStar,
    emptyStars
  };
};
